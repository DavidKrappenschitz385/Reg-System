<?php
require_once 'admin/db_con.php';
session_start();

if (!isset($_SESSION['user_login'])) {
    header('Location: admin/login.php');
    exit();
}

$username = $_SESSION['user_login'];
$stmt = mysqli_prepare($db_con, "SELECT * FROM `users` WHERE `username` = ?");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user || $user['role'] !== 'default') {
    header('Location: profile.php');
    exit();
}

if (isset($_POST['request_role'])) {
    $role = $_POST['role'];
    $doc = $_FILES['document'];

    $doc_name = $doc['name'];
    $doc_tmp = $doc['tmp_name'];
    $doc_size = $doc['size'];
    $doc_error = $doc['error'];

    $doc_ext = explode('.', $doc_name);
    $doc_ext = strtolower(end($doc_ext));

    $allowed = array('jpg', 'jpeg', 'png', 'pdf');

    if (in_array($doc_ext, $allowed)) {
        if ($doc_error === 0) {
            if ($doc_size <= 5000000) { // 5MB
                $doc_name_new = $username . '_' . time() . '.' . $doc_ext;
                $doc_destination = 'admin/documents/' . $doc_name_new;

                if (move_uploaded_file($doc_tmp, $doc_destination)) {
                    $stmt = mysqli_prepare($db_con, "UPDATE `users` SET `role` = ?, `status` = 'pending', `eligibility_document` = ? WHERE `username` = ?");
                    mysqli_stmt_bind_param($stmt, "sss", $role, $doc_name_new, $username);
                    $result = mysqli_stmt_execute($stmt);

                    if ($result) {
                        $_SESSION['message'] = "Your role request has been submitted. Please wait for admin approval.";
                        header('Location: profile.php');
                        exit();
                    } else {
                        $error = "Failed to submit role request. Please try again.";
                    }
                } else {
                    $error = "Failed to upload document.";
                }
            } else {
                $error = "Your file is too large.";
            }
        } else {
            $error = "There was an error uploading your file.";
        }
    } else {
        $error = "You cannot upload files of this type.";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Request Role</title>
</head>
<body>
<div class="container">
    <br>
    <h1 class="text-center">Request a Role</h1>
    <br>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <?php if (isset($error)) { ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php } ?>
            <form method="POST" action="request-role.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="role">Select Role</label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="">Select a role</option>
                        <option value="player">Player</option>
                        <option value="coach">Coach</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="document">Eligibility Document</label>
                    <input type="file" name="document" id="document" class="form-control" required>
                </div>
                <button type="submit" name="request_role" class="btn btn-primary">Submit Request</button>
                <a href="admin/logout.php" class="btn btn-secondary">Logout</a>
            </form>
        </div>
    </div>
</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
